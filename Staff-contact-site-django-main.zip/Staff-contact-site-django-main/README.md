# Staff-contact-site-django
A site to communicate with employees and publish the tasks required of each department and the work that employees do and the latest company news .. I developed it using python django
